# Install node to run the app.
# after installation, navigate to the folder through command line
# type : npm start :  and the web app will run on http://localhost:3000/ on browser.
# Florian Chazizi
